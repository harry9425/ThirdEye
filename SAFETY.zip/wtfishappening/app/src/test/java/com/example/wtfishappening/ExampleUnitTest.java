package com.harrytheboss.wtfishappening;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * harrytheboss local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class harrythebossUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}