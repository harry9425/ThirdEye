package com.harrytheboss.wtfishappening;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class forgetpass extends AppCompatActivity {

    EditText id;
    public static String nameofuser;
    public static String phoneofuser;
    private DatabaseReference mDatabase,mDatabase2;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpass);
        id=(EditText) findViewById(R.id.username);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

    }
    public void hello(View view)
    {
        nameofuser=id.getText().toString().toLowerCase();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        progressDialog=new ProgressDialog(forgetpass.this);
        progressDialog.setMessage("CHECKING CREDENTIALS");
        progressDialog.show();
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild("user:"+nameofuser)) {
                    Toast.makeText(forgetpass.this, "ACCOUNT FOUND", Toast.LENGTH_LONG).show();
                    getusernumber();
                }
                else {
                    progressDialog.dismiss();
                    Toast.makeText(forgetpass.this, "ACCOUNT DOES NOT EXISTS", Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(forgetpass.this, "ERROR:INTERNET IS LOW", Toast.LENGTH_LONG).show();

            }
        });
    }

    private void getusernumber()
    {
        mDatabase2 = FirebaseDatabase.getInstance().getReference().child("user:"+nameofuser).child("phone");
        mDatabase2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss();
                Toast.makeText(forgetpass.this, "GETTING DATA FROM SERVER", Toast.LENGTH_LONG).show();
                phoneofuser="+91"+snapshot.getValue().toString();
                Intent intent = new Intent(forgetpass.this, resetallow.class);
                startActivity(intent);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(forgetpass.this, "CAN'T CONNECT TO SERVER", Toast.LENGTH_LONG).show();
            }
        });
    }
}
