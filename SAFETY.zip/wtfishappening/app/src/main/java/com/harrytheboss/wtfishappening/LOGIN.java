package com.harrytheboss.wtfishappening;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.KeyguardManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class LOGIN extends AppCompatActivity {

    public static String name, password;
    private DatabaseReference mDatabase;
    ProgressDialog progressDialog;
    Checkable checkable;
    EditText user, passkey;


    public void openstore(View view) {
        final String appPackageName = getPackageName();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    public void openmail(View view)
    {
        Intent intent = new Intent(Intent.ACTION_SENDTO); // it's not ACTION_SEND
        intent.putExtra(Intent.EXTRA_SUBJECT, "Found a bug in your app THIRD EYE");
        intent.setData(Uri.parse("mailto:hitanshagrawal@gmail.com")); // or just "mailto:" for blank
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // this will make such that when user returns to your app, your app is displayed, instead of the email app.
        startActivity(intent);
    }

    public void confirm(View view) {
        Intent intent34 = new Intent(LOGIN.this, forgetpass.class);
        startActivity(intent34);
    }

    public void checkdatabase() {
        mDatabase = FirebaseDatabase.getInstance().getReference().child("user:"+name).child("login");
        progressDialog = new ProgressDialog(LOGIN.this);
        if (checkable.isChecked()) {
            progressDialog.setMessage("CHECKING CREDENTIALS");
            progressDialog.show();
            mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.hasChild("login"+name+password)) {
                        progressDialog.dismiss();
                        Toast.makeText(LOGIN.this, "LOGGED IN SUCCESSFULLY", Toast.LENGTH_LONG).show();

                            Intent intent = new Intent(LOGIN.this, chooser.class);
                            startActivity(intent);
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(LOGIN.this, "WRONG ID/PASSWORD", Toast.LENGTH_LONG).show();

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    progressDialog.dismiss();
                    Toast.makeText(LOGIN.this, "CAN'T CONNECT TO INTERNET", Toast.LENGTH_LONG).show();

                }
            });
        } else {
            Toast.makeText(LOGIN.this, "PLEASE CHECK THE CHECKBOX TO GO AHEAD", Toast.LENGTH_LONG).show();
        }
    }
    public void login(View view)
    {
        user = (EditText) findViewById(R.id.username);
        passkey = (EditText) findViewById(R.id.passkey);
        name = user.getText().toString().toLowerCase();
        password = passkey.getText().toString().toLowerCase();
        if (name.isEmpty() && password.isEmpty()) {
            Toast.makeText(this, "PLEASE ENTER ABOVE FIELDS", Toast.LENGTH_SHORT).show();
        } else if (name.isEmpty() || password.isEmpty()) {
            if (name.isEmpty()) {
                Toast.makeText(this, "PLEASE ENTER YOUR USERNAME", Toast.LENGTH_SHORT).show();
            }
            if (password.isEmpty()) {
                Toast.makeText(this, "PLEASE ENTER YOUR PASSWORD", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            checkdatabase();

        }
    }

    public void signup(View view)
    {
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l_o_g_i_n);
        checkable = (CheckBox) findViewById(R.id.remember);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }


    }

}

