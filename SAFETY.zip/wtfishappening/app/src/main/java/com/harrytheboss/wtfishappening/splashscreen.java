package com.harrytheboss.wtfishappening;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.VideoView;

public class splashscreen extends AppCompatActivity {

public static int please=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        VideoView video = (VideoView) findViewById(R.id.videoView);
        video.setVideoPath("android.resource://" + getPackageName() + "/" + R.raw.intro);
        video.seekTo(500);
        video.start();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent2=new Intent(splashscreen.this,LOGIN.class);
                startActivity(intent2);
                finish();
            }
        },3700);
    }
}
