package com.harrytheboss.wtfishappening;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class signup extends AppCompatActivity {

   public static String name,password,password2,emailid;
    private DatabaseReference mDatabase;
    ProgressDialog progressDialog;
    CheckBox allow;
    public static String userid;

    public void moreinfo(View view)
    {
        Intent intent = new Intent(signup.this, moreinfo.class);
        startActivity(intent);
    }


    public void login(View view)
    {
        EditText user = (EditText) findViewById(R.id.name);
        EditText passkey = (EditText) findViewById(R.id.pass);
        EditText passkey2 = (EditText) findViewById(R.id.pass2);
        EditText email = (EditText) findViewById(R.id.userid);
        name = user.getText().toString().toLowerCase();
        password = passkey.getText().toString().toLowerCase();
        password2 = passkey2.getText().toString().toLowerCase();
        emailid = email.getText().toString();
        if (name.isEmpty() && password.isEmpty() &&password2.isEmpty() && emailid.isEmpty()) {
            Toast.makeText(this, "PLEASE ENTER ABOVE FIELDS", Toast.LENGTH_SHORT).show();
        } else if (name.isEmpty() || password.isEmpty()|| password2.isEmpty()|| emailid.isEmpty()) {
            if (name.isEmpty()) {
                Toast.makeText(this, "PLEASE ENTER YOUR USERNAME", Toast.LENGTH_SHORT).show();
            }
            if (password.isEmpty()) {
                Toast.makeText(this, "PLEASE ENTER YOUR PASSWORD", Toast.LENGTH_SHORT).show();
            }
            if (password2.isEmpty()) {
                Toast.makeText(this, "PLEASE CONFIRM YOUR PASSWORD", Toast.LENGTH_SHORT).show();
            }
            if (emailid.isEmpty()) {
                Toast.makeText(this, "PLEASE ENTER YOUR EMAIL ID", Toast.LENGTH_SHORT).show();
            }
        }
        else if(password.length()>=6 && password2.length()>=6){
            if(password.equals(password2)) {
                if(allow.isChecked())
                checkifanyexists();
                else
                    Toast.makeText(this, "CHECK THE CHECKBOX", Toast.LENGTH_SHORT).show();
                }
            else {
                Toast.makeText(this, "PASSWORDS DON'T MATCH", Toast.LENGTH_SHORT).show();
            }
            }
        else
        {
            Toast.makeText(this, "PASSWORD MUST BE 6 CHARACTER", Toast.LENGTH_SHORT).show();
        }
    }

    public void checkifanyexists()
    {
        mDatabase = FirebaseDatabase.getInstance().getReference();
        progressDialog=new ProgressDialog(signup.this);
        progressDialog.setMessage("CHECKING CREDENTIALS");
        progressDialog.show();
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild("user:"+name)) {
                    progressDialog.dismiss();
                    Toast.makeText(signup.this, "USERNAME NOT AVAILABLE", Toast.LENGTH_LONG).show();

                }
                else {
                    progressDialog.dismiss();
                    save();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(signup.this, "ERROR:INTERNET IS LOW", Toast.LENGTH_LONG).show();

            }
        });
    }

   public void save()
   {
      Intent intent = new Intent(getApplicationContext(), otpverification.class);
        otpverification.phoneNo="+91"+emailid;
        startActivity(intent);
   }

   void adddata() {
           progressDialog = new ProgressDialog(signup.this);
           progressDialog.setMessage("CREATING ACCOUNT");
           progressDialog.show();
           mDatabase.child("user:" + name).child("login").child("login" + name + password).setValue( name + password).addOnCompleteListener(new OnCompleteListener<Void>() {
               @Override
               public void onComplete(@NonNull Task<Void> task) {
                   if (task.isSuccessful()) {
                       Toast.makeText(signup.this, "CREATED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                      addnodata();

                   } else {
                       progressDialog.dismiss();
                       Toast.makeText(signup.this, "YOUR INTERNET IS LOW", Toast.LENGTH_SHORT).show();
                   }
               }
           });
   }
   private void addnodata()
   {
       mDatabase.child("user:" + name).child("phone").setValue(emailid).addOnCompleteListener(new OnCompleteListener<Void>() {
           @Override
           public void onComplete(@NonNull Task<Void> task) {
               if (task.isSuccessful()) {
                   addnodata2();

               } else {
                   progressDialog.dismiss();
                   Toast.makeText(signup.this, "YOUR INTERNET IS LOW", Toast.LENGTH_SHORT).show();
               }
           }
       });
   }
    private void addnodata2()
    {
        mDatabase.child("user:" + name).child("address").setValue("NO PREVIOUS RECORD FOUND").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    addnodata3();

                } else {
                    progressDialog.dismiss();
                    Toast.makeText(signup.this, "YOUR INTERNET IS LOW", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void addnodata3()
    {
        mDatabase.child("user:" + name).child("coordinates").setValue("20.5937,78.9629").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    progressDialog.dismiss();
                    Toast.makeText(signup.this, "CREATED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(signup.this, LOGIN.class);
                    otpverification.access=0;
                    startActivity(intent);
                    finish();

                } else {
                    progressDialog.dismiss();
                    Toast.makeText(signup.this, "YOUR INTERNET IS LOW", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
         mDatabase = FirebaseDatabase.getInstance().getReference();
         allow=(CheckBox) findViewById(R.id.allowcheckbox);
         if(otpverification.access==1)
         {
             adddata();
         }
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
         }
}
