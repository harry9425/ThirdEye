package com.harrytheboss.wtfishappening;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import static com.harrytheboss.wtfishappening.app.CHANNEL_1_ID;

public class chooser extends AppCompatActivity {

    public void gpsproblemsstart(View view)
    {
        Intent intent = new Intent(this, gpsproblems.class);
        startActivity(intent);

    }
    public void gpsproblemsstart2(View view)
    {
        Intent intent = new Intent(this, parkingstart.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chooser);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

}
