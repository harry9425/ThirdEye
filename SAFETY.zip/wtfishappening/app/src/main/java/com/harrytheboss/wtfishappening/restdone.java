package com.harrytheboss.wtfishappening;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class restdone extends AppCompatActivity {
    private DatabaseReference mDatabase24;
    ProgressDialog progressDialog;
    String password,password2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restdone);
        mDatabase24= FirebaseDatabase.getInstance().getReference();
        Toast.makeText(this, "WELCOME "+forgetpass.nameofuser.toUpperCase(), Toast.LENGTH_SHORT).show();
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        }
    public void proceed(View view)
    {
        EditText pass1=(EditText) findViewById(R.id.liker);
        EditText pass2=(EditText) findViewById(R.id.bsdl);
        password=pass1.getText().toString();
        password2=pass2.getText().toString();
        if (password.isEmpty() &&password2.isEmpty()) {
            Toast.makeText(this, "PLEASE ENTER ABOVE FIELDS", Toast.LENGTH_SHORT).show();
        } else if (password.isEmpty()|| password2.isEmpty()) {

            if (password.isEmpty()) {
                Toast.makeText(this, "PLEASE ENTER YOUR PASSWORD", Toast.LENGTH_SHORT).show();
            }
            if (password2.isEmpty()) {
                Toast.makeText(this, "PLEASE CONFIRM YOUR PASSWORD", Toast.LENGTH_SHORT).show();
            }
        }
        else if(password.length()>=6 && password2.length()>=6){
            if(password.equals(password2)) {
                addchanges();
            }
            else {
                Toast.makeText(this, "PASSWORDS DON'T MATCH", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(this, "PASSWORD MUST BE 6 CHARACTER", Toast.LENGTH_SHORT).show();
        }
    }

    public void addchanges()
    {
        mDatabase24.child("user:"+ forgetpass.nameofuser).child("login").removeValue();
        mDatabase24.child("user:"+ forgetpass.nameofuser).child("login").child("login"+forgetpass.nameofuser+password).setValue(forgetpass.nameofuser+password).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(restdone.this, "PASSWORD CHANGED", Toast.LENGTH_LONG).show();
                    Intent intent34 = new Intent(restdone.this, LOGIN.class);
                    startActivity(intent34);
                }
                else {
                    Toast.makeText(restdone.this, "ERROR OCCURRED", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    }

