package com.harrytheboss.wtfishappening;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.DialogFragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.app.Notification;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import static com.harrytheboss.wtfishappening.app.CHANNEL_1_ID;

public class parkingstart extends AppCompatActivity {

    private static final int REQUEST_CODE_CONFIRM_DEVICE_CREDENTIALS = 1;
    private int open=0;

    public void confirm()
    {
        KeyguardManager mKeyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (!mKeyguardManager.isKeyguardSecure()) {
            Toast.makeText(this, "CAN'T OPEN THE PAGE,TO OPEN THE PAGE FIRST \n GO TO SETTING>SECURITY AND ADD LOCK TO YOUR DEVICE", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Intent intent = mKeyguardManager.createConfirmDeviceCredentialIntent(null, null);
            if (intent != null) {
                startActivityForResult(intent, REQUEST_CODE_CONFIRM_DEVICE_CREDENTIALS);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CONFIRM_DEVICE_CREDENTIALS) {
            if (resultCode == RESULT_OK) {

                DialogFragment dialog = new parkingstart.MyDialogFragment();
                dialog.show(getSupportFragmentManager(), "MyDialogFragmentTag");

            } else {
                Toast.makeText(this, "AUTHENTICATION CANCELLED", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void gotocurrent(View view)
    {
        DialogFragment dialog = new parkingstart.MyDialogFragment();
        dialog.show(getSupportFragmentManager(), "MyDialogFragmentTag");
    }
    public void showtocurrent(View view)
    {
     confirm();
    }
    public void showallcurrent(View view)
    {
     confirm();
    }
    public  static class MyDialogFragment extends DialogFragment {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("UPDATE FROM THIRD EYE");
            builder.setMessage("Page not available, will be added in new update");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                }
            });

            return builder.create();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parkingstart);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }
}
